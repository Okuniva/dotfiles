// ==UserScript==
// @name         Google Account Auto-Select
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Auto-click Google account on login page
// @match        *://accounts.google.com/*
// @grant        none
// ==/UserScript==
(function() {
    'use strict';

    function isVisible(el) {
        return el && el.offsetParent !== null;
    }

    function waitAndClickSelector(selector, maxTries = 20, delay = 500) {
        return new Promise((resolve, reject) => {
            let tries = 0;
            const interval = setInterval(() => {
                const el = document.querySelector(selector);
                console.log(`[AutoLogin][Try ${tries + 1}/${maxTries}] Searching for selector: ${selector}`);

                if (el) {
                    console.log("[AutoLogin] Element found:", el);
                    if (isVisible(el)) {
                        console.log("[AutoLogin] Element is visible, clicking...");
                        el.click();
                        clearInterval(interval);
                        resolve(true);
                    } else {
                        console.log("[AutoLogin] Element found but not visible yet.");
                    }
                }

                if (++tries >= maxTries) {
                    clearInterval(interval);
                    reject(`[AutoLogin] Element not found or not visible after ${maxTries} tries: ${selector}`);
                }
            }, delay);
        });
    }

    window.addEventListener('load', () => {
        waitAndClickSelector('[data-identifier="aleksandr.valeev@indriver.com"]')
            .then(() => console.log("[AutoLogin] Success"))
            .catch(err => console.log("[AutoLogin] ERROR:", err));
    });
})();
