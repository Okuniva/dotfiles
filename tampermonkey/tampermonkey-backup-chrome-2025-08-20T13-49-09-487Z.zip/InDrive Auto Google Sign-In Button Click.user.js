// ==UserScript==
// @name         InDrive Auto Google Sign-In Button Click
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Click "Sign in with Google" button on InDrive sites
// @match        *://*.indrive.dev/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function clickGoogleButton() {
        const buttons = document.querySelectorAll('button[data-testid="Button"]');
        for (const btn of buttons) {
            const span = btn.querySelector('span');
            if (span && span.textContent.trim() === "Sign in with Google") {
                console.log("[AutoLogin] Clicking Google Sign-In button...");
                btn.click();
                return;
            }
        }
    }

    const observer = new MutationObserver(() => {
        clickGoogleButton();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    window.addEventListener('load', () => {
        clickGoogleButton();
    });

    console.log("[Tampermonkey] Script is running on InDrive");
})();
