// ==UserScript==
// @name         Gmail Cmd + > Delete
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Press Cmd+> to click Gmail's Delete button
// @author       You
// @match        https://mail.google.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener("keydown", function(e) {
        // ⌘+>  (Shift + . + Cmd)
        if (e.metaKey && e.shiftKey && e.key === ".") {
            e.preventDefault();

            let firstEmail = document.querySelector('tr.zA'); // Gmail email row
if (firstEmail && !firstEmail.classList.contains('yO')) { // if not already selected
    firstEmail.click(); // select it
}


            let btn = document.querySelector('div[aria-label="Delete"]');
            if (btn) {
                btn.click();
                console.log("[Gmail Hotkey] Delete button clicked via Cmd+>");
            } else {
                console.log("[Gmail Hotkey] Delete button not found");
            }
        }
    });
})();
