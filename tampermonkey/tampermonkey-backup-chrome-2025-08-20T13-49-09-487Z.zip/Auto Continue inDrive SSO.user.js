// ==UserScript==
// @name         Auto Continue inDrive SSO
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Auto-click Continue button on GitHub inDriver SSO page
// @author       You
// @match        https://github.com/inDriver*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function clickContinueIfNeeded() {
        const title = document.querySelector("h1.sso-title.m-0");
        if (title && title.innerText.includes("Single sign-on to") && title.innerText.includes("inDrive")) {
            const btn = document.querySelector("button.btn-primary.btn.btn-block");
            if (btn) {
                console.log("Auto-clicking Continue button...");
                btn.click();
            }
        }
    }

    // Run immediately after page load
    window.addEventListener("load", () => {
        clickContinueIfNeeded();

        // Also observe DOM changes in case content loads dynamically
        const observer = new MutationObserver(clickContinueIfNeeded);
        observer.observe(document.body, { childList: true, subtree: true });
    });
})();
