// ==UserScript==
// @name         Google Continue Button Auto-Click
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Auto-click Continue button on Google login page
// @match        *://accounts.google.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function isVisible(el) {
        return el && el.offsetParent !== null;
    }

    function findElementByXPath(xpath) {
        const result = document.evaluate(
            xpath,
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        );
        return result.singleNodeValue;
    }

    function waitAndClickXPath(xpath, maxTries = 20, delay = 500) {
        return new Promise((resolve, reject) => {
            let tries = 0;
            const interval = setInterval(() => {
                const el = findElementByXPath(xpath);
                if (el && isVisible(el)) {
                    console.log("[AutoLogin] Clicking element by XPath:", xpath);
                    el.click();
                    clearInterval(interval);
                    resolve(true);
                } else if (++tries >= maxTries) {
                    clearInterval(interval);
                    reject(`Element not found by XPath: ${xpath}`);
                }
            }, delay);
        });
    }

    window.addEventListener('load', () => {
        waitAndClickXPath("//button[span[text()='Continue']]")
            .catch(err => console.log("[AutoLogin]", err));
    });
})();
